#ifndef MY_STRING_H
#define MY_STRING_H


class My_String
{
    public:
        My_String();
        virtual ~My_String();

    protected:

    private:
};

#endif // MY_STRING_H
