#include "My_String.h"

My_String::My_String()
{
    //ctor
}

My_String::~My_String()
{
    //dtor
}
