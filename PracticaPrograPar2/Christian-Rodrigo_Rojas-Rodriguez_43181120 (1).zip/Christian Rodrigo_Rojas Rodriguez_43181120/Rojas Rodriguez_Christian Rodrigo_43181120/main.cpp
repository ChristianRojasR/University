#include <iostream>
#include "Cadena.h"

using namespace std;

int main()
{
    Cadena cad1 = "Final Programacion 1110";
    Cadena cfinal;
    cout << (cfinal = cad1+", UNLaM. 27/10/2022") << endl;
    return 0;
}
